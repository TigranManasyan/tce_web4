<?php 
	return mysqli_connect("localhost", "root", "", "edu"); 
?>